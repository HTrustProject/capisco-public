package org.afox.capisco;

import java.io.*;
import java.net.*;
import java.util.*;

import core.CommandQueue;
import core.Main;
import core.PortHandler;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.store.FSDirectory;

public class Capisco extends Main
{
	private IndexSearcher luceneIndex;
	private MongoClient mongoClient;
	private DB db;

	public Capisco(int aPort, int threadCount, String indexLocation)
	{
		super(aPort, threadCount);
		initMongoDBAccess();
		initLuceneAccess(indexLocation);

		start();
	}

	private void initMongoDBAccess()
	{
		try
		{
			mongoClient = new MongoClient();
			db = mongoClient.getDB("wikipedia");
		}
		catch (Exception x)
		{
			System.out.println("Exception caught while attempting to open MongoDB: " + x);
			System.exit(-1);
		}
	}

	private void initLuceneAccess(String indexLocation)
	{
		try
		{
			IndexReader reader = DirectoryReader.open(FSDirectory.open(new File(indexLocation)));
			luceneIndex = new IndexSearcher(reader);
		}
		catch(Exception x)
		{
			System.out.println("Exception caught while attempting to open Lucene index:" + x);
			System.exit(-1);
		}
	}

	public DBCollection getCollection(String name)
	{
		return db.getCollection(name);
	}

	protected PortHandler createPortHandler(Socket serverSocket,
			CommandQueue commandQueue) throws IOException {
		return new CapiscoPortHandler(serverSocket, commandQueue, this);
	}

	public IndexSearcher getLuceneIndex()
	{
		return luceneIndex;
	}

	public static void main(String[] args)
	{
		new Capisco(3434, 4, args[0]);
	}
}